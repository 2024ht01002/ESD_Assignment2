#include <stdint.h>
#include "lcd.h"
#include <lpc23xx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to create a delay
void delay(int time) {
    int i, j;
    for (i = 0; i < time; i++)
        for (j = 0; j < 1000; j++);
}

int main() {
    char voltage_str[20] = "";
    uint32_t adc_data = 0;
    float volt = 0;

    // Initialize ADC
    PCONP |= (1 << 12);        // Power up the ADC
    PINSEL1 |= (1 << 14);      // Set P0.23 as AD0.0
    PINSEL1 &= ~(1 << 15);     
    AD0INTEN |= (1 << 0);      // Enable interrupt for AD0.0

    // Configure ADC: select AD0.0, 4 MHz clock, 10-bit resolution, operational mode
    AD0CR &= ~(1 << 0);        // Clear channel select bits
    AD0CR |= (1 << 9);         // Set clock divider for 4 MHz
    AD0CR |= (1 << 16);        // Disable BURST mode (manual control)
    AD0CR |= (1 << 21);        // Enable ADC

    // Initialize LCD
    lcd_init();
    lcd_clear();

    // Display BITS ID on the first line
    set_cursor(0, 0);
    lcd_print((unsigned char *)"BITS 2024HT01002");

    while (1) {
        set_cursor(0, 1);

        // Wait for ADC conversion to complete
        while (!(AD0STAT & (1 << 0))) {};

        // Retrieve the ADC result
        adc_data = (AD0DR0 & 0x0000FFC0) >> 6;

        // Convert ADC value to voltage
        volt = ((adc_data / 1023.0) * 3.3);

        // Format voltage as a string for display
        sprintf(voltage_str, "%.2fV ", volt);

        // Display voltage and date on the second line
        lcd_print((const unsigned char *)voltage_str);
        lcd_print((const unsigned char *)"Date:16/10");

        delay(1);
    }
}